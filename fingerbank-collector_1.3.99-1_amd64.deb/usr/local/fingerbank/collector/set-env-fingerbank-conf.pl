#!/usr/bin/perl

# Allows to setup the environment of the collector based on the content of fingerbank.conf


# /usr/bin/systemctl set-environment FINGERBANK_API_KEY=$(perl -I/usr/local/fingerbank/lib -Mfingerbank::Config -e 'print fingerbank::Config->read_config ; print $fingerbank::Config::Config{upstream}->{api_key}')"

use strict;
use warnings;

use lib '/usr/local/fingerbank/lib';
use lib '/usr/local/pf/lib';
use lib '/usr/local/pf/lib_perl/lib/perl5';
use fingerbank::Config;
use fingerbank::Log;
use fingerbank::FilePath qw($COLLECTOR_ENDPOINTS_DATA_FILE $COLLECTOR_IP_MAPS_FILE $COLLECTOR_ENDPOINTS_CACHE_FILE);
use fingerbank::Util qw(is_enabled);
use File::Slurp qw(read_file);
use Data::Dumper;
use pf::cluster;

our $FINGERBANK_COLLECTOR_ENV_DEFAULTS = "/usr/local/pf/conf/fingerbank-collector.env.defaults";

sub setenv {
    my ($variable, $value) = @_;
    # Older versions of this file were setting values via 'systemctl set-environment' so this line below makes sure they are unset
    system("systemctl unset-environment $variable");
    print "export $variable=$value\n";
}

fingerbank::Config->read_config;

# Allows to get the servers for the new cluster zone feature
# In the event the collector runs on the codebase without this feature, then this will return empty servers
sub get_servers {
    no warnings;
    my @servers = @pf::cluster::config_cluster_servers;
    return @servers ? \@servers : [];
}

# Performs the environment base setup from the env file in /usr/local/pf/conf/fingerbank-collector.env.defaults if its there
sub setup_from_env_file {
    return unless -f $FINGERBANK_COLLECTOR_ENV_DEFAULTS;
    my @declarations = split("\n", read_file($FINGERBANK_COLLECTOR_ENV_DEFAULTS));
    for my $declaration (@declarations) {
        my ($key, $value) = split("=", $declaration);
        setenv($key, $value);
    }
}


my %Config = %fingerbank::Config::Config;

my %TO_SET = (
    "FINGERBANK_API_KEY" => $Config{upstream}->{api_key},,
    "COLLECTOR_DELETE_INACTIVE_ENDPOINTS" => $Config{collector}->{inactive_endpoints_expiration} . "h",
    "COLLECTOR_ARP_LOOKUP" => is_enabled($Config{collector}->{arp_lookup}) ? "true" : "false",
    "COLLECTOR_QUERY_CACHE_TIME" => $Config{collector}->{query_cache_time} . "m",
    "PORT" => $Config{collector}->{port},
    "COLLECTOR_ENDPOINTS_DB_PATH" => $COLLECTOR_ENDPOINTS_DATA_FILE,
    "COLLECTOR_ENDPOINTS_CACHE_PATH" => $COLLECTOR_ENDPOINTS_CACHE_FILE,
    "COLLECTOR_IP_MAPS_DB_PATH" => $COLLECTOR_IP_MAPS_FILE,
    "COLLECTOR_DB_PERSISTENCE_INTERVAL" => $Config{collector}->{db_persistence_interval} . "s",
    "COLLECTOR_CLUSTER_RESYNC_INTERVAL" => $Config{collector}->{cluster_resync_interval} . "s",
    "COLLECTOR_CLUSTERED" => "true",
    "GOGC" => "100",
    "GODEBUG" => "gctrace=0",
    "HTTP_PROXY" => fingerbank::Util::get_proxy_url("http"),
    "HTTPS_PROXY" => fingerbank::Util::get_proxy_url("http"),
    "COLLECTOR_CONTACT_PEERS" => join ",", map{ $_->{management_ip} } @{get_servers()},
);

if(is_enabled($Config{collector}->{network_behavior_analysis})) {
    %TO_SET = (
        %TO_SET,
        "COLLECTOR_NETWORK_BEHAVIOR_ANALYSIS" => "true",
        "COLLECTOR_NETWORK_BEHAVIOR_POLICIES" => "/usr/local/pf/conf/network_behavior_policies.conf",
        "COLLECTOR_ENDPOINT_ANALYSIS_WEBHOOK" => "http://localhost:9090/fingerbank/nba/webhook",
    );
}
else {
    $TO_SET{"COLLECTOR_NETWORK_BEHAVIOR_ANALYSIS"} = "false";
}

setup_from_env_file();

while(my ($k, $v) = each(%TO_SET)) {
    setenv($k, $v);
}

